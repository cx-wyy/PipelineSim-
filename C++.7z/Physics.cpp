#include "Physics.h"
#include <cmath>
#include <algorithm>
#include <iostream>

struct API_Coeffs { double K0; double K1; double K2; };

API_Coeffs getK_Values(double rho) {
    if (rho >= 610.6 && rho < 770.35)       return { 192.4571, 0.2438, 0.0 };
    else if (rho >= 770.35 && rho < 787.52) return { 1489.067, 0.0, -0.0018684 };
    else if (rho >= 787.52 && rho < 838.31) return { 330.301, 0.0, 0.0 };
    else                                    return { 103.8720, 0.2701, 0.0 };
}

Physics::OilParams Physics::calculateLockedOilProperties(double rho_std_kgm3) {
    OilParams oil;
    oil.rho_std = rho_std_kgm3;

    // 1. Alpha ����
    API_Coeffs K = getK_Values(rho_std_kgm3);
    double alpha_US = K.K0 / (rho_std_kgm3 * rho_std_kgm3) + K.K1 / rho_std_kgm3 + K.K2;
    oil.alpha_metric = alpha_US * 1.8; // F -> K

    // 2. Bt ����
    double A = -1.99470, B = 0.00013427, C = 793920.0, D = 2326.0;
    double t_ref_F = 60.0;
    double exponent = A + B * t_ref_F + (C + D * t_ref_F) / (rho_std_kgm3 * rho_std_kgm3);
    double Fp_psi = std::exp(exponent);
    double Fp_metric = Fp_psi / 6894.76; // psi -> Pa
    oil.Bt_metric = 1.0 / Fp_metric;

    std::cout << "[Physics] Oil Initialized. Bt: " << oil.Bt_metric / 1e9 << " GPa" << std::endl;
    return oil;
}

double Physics::calculateDensity(double P, double T, const OilParams& oil) {
    double T_std = 288.15;
    double P_std = 101325.0;
    double term_temp = oil.alpha_metric * (T - T_std);
    double term_press = (P - P_std) / oil.Bt_metric;

    double rho = oil.rho_std * (1.0 - term_temp + term_press);
    // ��ȫ��飺��ֹ����ը�ɵ��¸��ܶ�
    if (rho < 100.0) rho = 100.0;
    return rho;
}

double Physics::calculateWaveSpeed(double rho, double Ks, double D, double delta, double E, double C1) {
    if (rho <= 0) rho = 850.0; // ����
    double numerator = Ks / rho;
    double denominator_term = (Ks * D * C1) / (E * delta);
    return std::sqrt(numerator / (1.0 + denominator_term));
}

double Physics::calculateFriction(double Re, double relativeRoughness) {
    if (Re < 1.0) Re = 1.0; // ��ֹReΪ0
    if (Re < 2300.0) return 64.0 / Re;

    double f_guess = 0.02;
    for (int i = 0; i < 50; ++i) {
        double sqrt_f = std::sqrt(f_guess);
        double term = (relativeRoughness / 3.7) + (2.51 / (Re * sqrt_f));
        double g_val = -2.0 * std::log10(term);
        if (std::abs(g_val) < 1e-9) g_val = 0.001; // ��ֹ��0
        double F = (1.0 / sqrt_f) - g_val;
        if (std::abs(F) < 1e-6) return f_guess;
        f_guess = 1.0 / (g_val * g_val);
    }
    return f_guess;
}