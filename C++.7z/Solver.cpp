#include "Solver.h"
#include "Physics.h"
#include <cmath>
#include <iostream>
#include <algorithm>

std::vector<double> Solver::solveLinearSystem(std::vector<std::vector<double>>& A, std::vector<double>& b) {
    int n = b.size();
    for (int i = 0; i < n; ++i) {
        int pivot = i;
        for (int j = i + 1; j < n; ++j) {
            if (std::abs(A[j][i]) > std::abs(A[pivot][i])) pivot = j;
        }
        std::swap(A[i], A[pivot]);
        std::swap(b[i], b[pivot]);

        // �����������Ԫ̫С��˵���������죬ǿ����Ϊ��Сֵ��ֹNaN
        if (std::abs(A[i][i]) < 1e-20) A[i][i] = 1e-20;

        for (int j = i + 1; j < n; ++j) {
            double factor = A[j][i] / A[i][i];
            for (int k = i; k < n; ++k) A[j][k] -= factor * A[i][k];
            b[j] -= factor * b[i];
        }
    }
    std::vector<double> x(n);
    for (int i = n - 1; i >= 0; --i) {
        double sum = 0.0;
        for (int j = i + 1; j < n; ++j) sum += A[i][j] * x[j];
        x[i] = (b[i] - sum) / A[i][i];
    }
    return x;
}

std::vector<Node> Solver::solveStep(const std::vector<Node>& currentPipe, double dt, double dx,
    double P_inlet, double P_outlet,
    const Physics::OilParams& oil) {
    int N = currentPipe.size();
    int numVars = 2 * N;
    std::vector<std::vector<double>> A(numVars, std::vector<double>(numVars, 0.0));
    std::vector<double> b(numVars, 0.0);

    double theta = 0.55;
    double D = 0.5;
    double E = 2.06e11;
    double delta = 0.01;
    double C1 = 0.85;

    for (int i = 0; i < N - 1; ++i) {
        const Node& nL = currentPipe[i];
        const Node& nR = currentPipe[i + 1];

        double P_avg = (nL.P + nR.P) / 2.0;
        double T_avg = (nL.T + nR.T) / 2.0;
        double rho = Physics::calculateDensity(P_avg, T_avg, oil);
        double a = Physics::calculateWaveSpeed(rho, oil.Bt_metric, D, delta, E, C1);
        double a2 = a * a;

        double V_avg = (nL.V + nR.V) / 2.0; // ��������
        double V_abs = std::abs(V_avg);
        if (V_abs < 1e-6) V_abs = 1e-6; // ��ֹ��0

        double Re = (rho * V_abs * D) / 0.005; // ���һ��ճ�������ȶ���
        double f = Physics::calculateFriction(Re, 0.0001);

        int eq_cont = 2 * i;
        int eq_mom = 2 * i + 1;
        int idx_Pi = 2 * i;     int idx_Vi = 2 * i + 1;
        int idx_Pi1 = 2 * (i + 1); int idx_Vi1 = 2 * (i + 1) + 1;

        // �����Է���
        double coef_V = rho * a2 * theta / dx;
        double coef_P = 1.0 / (2.0 * dt);
        A[eq_cont][idx_Pi] = coef_P;   A[eq_cont][idx_Vi] = -coef_V;
        A[eq_cont][idx_Pi1] = coef_P;  A[eq_cont][idx_Vi1] = coef_V;

        double coef_V_old = rho * a2 * (1.0 - theta) / dx;
        b[eq_cont] = (nL.P + nR.P) * coef_P - (nR.V - nL.V) * coef_V_old;

        // ��������
        double coef_Mom_V = 1.0 / (2.0 * dt);
        double coef_Mom_P = 1.0 / (rho * dx) * theta;

        // ����Ħ��ϵ�� K = f / (2D)
        double K_fric = f / (2.0 * D);

        // 1. ��߾��� A (��ʽ����)
        // ����̩��չ��: 2 * |V_old| * V_new
        // ϵ���� 2 * K_fric * |V_old|
        double coef_Fric_LHS = K_fric * 2.0 * V_abs;

        A[eq_mom][idx_Pi] = -coef_Mom_P;
        A[eq_mom][idx_Vi] = coef_Mom_V + coef_Fric_LHS; // ע������ӵ��� coef_Fric_LHS
        A[eq_mom][idx_Pi1] = coef_Mom_P;
        A[eq_mom][idx_Vi1] = coef_Mom_V + coef_Fric_LHS;

        // 2. �ұ����� b (��ʽ����)
        // ԭʼ����: LHS_Terms + Fric_Terms = 0
        // չ��: LHS_Terms + K*(2|V|V_new - V|V|) = 0
        // ����: LHS_Terms + 2K|V|V_new = K * V * |V|
        // ���ԣ��ұ� b ����Ӧ�ü��� K * V * |V|

        double term_p_old = (1.0 - theta) / (rho * dx) * (nR.P - nL.P);

        // ע�⣺����ʹ�� V_avg (��������) * V_abs (����ֵ)
        double term_fric_RHS = K_fric * V_avg * V_abs;

        b[eq_mom] = (nL.V + nR.V) * coef_Mom_V - term_p_old + term_fric_RHS;
    }

    // �߽�����
    int idx_BC_Inlet = 2 * N - 2;
    A[idx_BC_Inlet][0] = 1.0;
    b[idx_BC_Inlet] = P_inlet;

    int idx_BC_Outlet = 2 * N - 1;
    A[idx_BC_Outlet][2 * (N - 1)] = 1.0;
    b[idx_BC_Outlet] = P_outlet;

    std::vector<double> x = solveLinearSystem(A, b);

    std::vector<Node> nextPipe = currentPipe;
    for (int i = 0; i < N; ++i) {
        nextPipe[i].P = x[2 * i];
        nextPipe[i].V = x[2 * i + 1];
        nextPipe[i].rho = Physics::calculateDensity(nextPipe[i].P, nextPipe[i].T, oil);
    }
    return nextPipe;
}