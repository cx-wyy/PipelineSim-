﻿#include <iostream>
#include <vector>
#include <fstream>
#include <iomanip>
#include "Node.h"
#include "Physics.h"
#include "Solver.h"

// 1. 保存时间序列 (用于看瞬态变化)
void saveTimeHistory(std::ofstream& file, double time, const std::vector<Node>& pipe) {
    int N = pipe.size();
    file << time << ","
        << pipe[0].P << "," << pipe[N / 2].P << "," << pipe[N - 1].P << ","
        << pipe[0].V << "," << pipe[N / 2].V << "," << pipe[N - 1].V << "\n";
}

// 2. 保存沿程分布 (这是你要的！用于看压降梯度)
void saveProfile(std::string filename, const std::vector<Node>& pipe) {
    std::ofstream file(filename);
    file << "Node_Index,Distance_m,Pressure_MPa,Velocity_m_s\n";
    double dx = 5000.0 / (pipe.size() - 1);
    for (int i = 0; i < pipe.size(); ++i) {
        file << i << ","
            << i * dx << ","
            << pipe[i].P / 1.0e6 << ","
            << pipe[i].V << "\n";
    }
    file.close();
    std::cout << ">> Profile data saved to " << filename << std::endl;
}

int main() {
    int N = 50;
    double Length = 5000.0;
    double dx = Length / (N - 1);

    Physics::OilParams myOil = Physics::calculateLockedOilProperties(850.0);

    std::vector<Node> pipe(N);
    for (int i = 0; i < N; ++i) {
        pipe[i].P = 101325.0; // 初始全线 1 atm
        pipe[i].V = 0.0;
        pipe[i].T = 293.15;
        pipe[i].rho = Physics::calculateDensity(pipe[i].P, pipe[i].T, myOil);
    }

    std::ofstream outFile("simulation_history.csv");
    outFile << "Time,P_In,P_Mid,P_Out,V_In,V_Mid,V_Out\n";

    std::cout << "Simulation Started with Soft Start..." << std::endl;

    double t = 0.0;
    double t_max = 200.0;
    double dt = 0.05;

    // 目标边界条件
    double Target_P_In = 5000000.0; // 5 MPa
    double Target_P_Out = 2000000.0; // 2 MPa

    while (t < t_max) {
        // --- 关键修改：软启动 (Soft Start) ---
        // 前 10秒 慢慢升压，防止计算炸飞
        double current_P_In;
        double current_P_Out;

        if (t < 10.0) {
            double ratio = t / 10.0;
            current_P_In = 101325.0 + (Target_P_In - 101325.0) * ratio;
            current_P_Out = 101325.0 + (Target_P_Out - 101325.0) * ratio;
        }
        else {
            current_P_In = Target_P_In;
            current_P_Out = Target_P_Out;
        }

        pipe = Solver::solveStep(pipe, dt, dx, current_P_In, current_P_Out, myOil);
        saveTimeHistory(outFile, t, pipe);

        if (std::abs(fmod(t, 5.0)) < dt) {
            std::cout << "Time: " << std::setw(5) << t << "s | "
                << "P_In: " << std::setprecision(2) << pipe[0].P / 1e6 << " MPa" << std::endl;
        }
        t += dt;
    }

    // --- 仿真结束，输出你要的“压降梯度表” ---
    std::cout << "\n--- Verification: Pressure Gradient ---" << std::endl;
    std::cout << "Inlet  Pressure: " << pipe[0].P / 1e6 << " MPa" << std::endl;
    std::cout << "Outlet Pressure: " << pipe[N - 1].P / 1e6 << " MPa" << std::endl;

    // 生成 profile_final.csv
    saveProfile("profile_final.csv", pipe);

    outFile.close();
    std::cout << "Done. Open 'profile_final.csv' to see the pressure drop along the pipe." << std::endl;
    system("pause");
    return 0;
}